# Importing necessary packages
import spacy
nlp = spacy.load("en_core_web_md")

# Loading all the text file
text = open("./data/TCY/text.txt").read()
org_text = nlp(text)
print(org_text)

ans1 = open("./data/TCY/ans1.txt").read()
ans1_text = nlp(ans1)
print(ans1_text)

ans2 = open("./data/TCY/ans2.txt").read()
ans2_text = nlp(ans2)
print(ans2_text)

ans3 = open("./data/TCY/ans3.txt").read()
ans3_text = nlp(ans3)
print(ans3_text)

# Comparing the similarity of the original text file and answer file.
org_text.similarity(ans1_text)
org_text.similarity(ans2_text)
org_text.similarity(ans3_text)
